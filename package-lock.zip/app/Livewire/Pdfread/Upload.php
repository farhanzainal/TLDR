<?php

namespace App\Livewire\Pdfread;

use Livewire\Component;

class Upload extends Component
{
    public function render()
    {
        return view('livewire.pdfread.upload');
    }
}
